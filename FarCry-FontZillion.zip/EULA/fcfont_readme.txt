*******************************************************************************

Font:    FarCry Logo Font v1.1 
Author:  Mike "Gumby" Anderson (gumby_um902@hotmail.com)
Date:    May 17, 2004
Install: Copy font (.ttf) to your Windows\Fonts folder.

Uninstall : To install a new version, or to remove, you must go to your 
	    c:\Windows\Fonts and delete FARCEB__.TTF "FarCry ExtraBold"
	    Then copy the new version to this folder to install the new version.
*******************************************************************************

What's New:
(This is almost a complete uppercase font now, only missing minor little used chars like tilde and curley brackets)

- Rescaled some of the symbols
- Added a lot more punctuation (almost all)
- Changed the width of the space char. (made more narrow)
- Changed some letter spacing, still not perfect ;/
- Punctuation included in this version:
  ! @ # $ % ^ & * ( ) [ ] : ; " ' < > , . ? / \ | ` - _ + =

- Symbols included
  a - Palm Tree
  b - Dual Banana Palms
  c - Smaller "C"
  d - Krieger corp Logo 1
  e - Ubisoft Logo
  f - Smaller "F"
  g - Ubisoft Logo Graphic
  h - UBISOFT Text
  i - CryTek Logo
  j - CryEngine Logo
  k - Biohazard
  l - Radiation Hazard
  m - Radiation Hazard Reversed
  n - Skull & Bones
  o - Bloody Palm Print
  p - NVidia Logo
  q - Ducky (Dont ask)
  r - Krieger Corp Logo 2
  s - FARCRY Logo
  t - NOT USED
  u - NOT USED
  v - NOT USED
  w - NOT USED
  x - NOT USED
  y - NOT USED
  z - NOT USED


*******

This font is released as freeware. It is for personal non-commercial use (Duh...) I released this because I got tired of seeing the "clone brush" sigs on the farcry forums ;) he he. Now you have a font! Use it to supplement the web-kit supplied by Ubisoft. Mod authors who use this font in their mods are asked to give me a mention in the credits, Thanks.

I have tried to recreate the look of the original font, which is pretty hard to do when you only have the letters "FARC, and Y". I am sure the Crytek/Ubi guys have a font, so I figured we should have one too. Took a while to find the root font, then I started from there. I was just going to release a package of Photoshop Custom Shapes, then I decided on a font. I still have the custom vector shapes for anyone who wants them.

The font is mainly uppercase, there are two lower case letters "f", and "c" the upper case versions of these letters are taller, the "F" is higher, and the "C" hangs lower. Use the lower case versions when you want them to resemble the rest of the uppercase letters. The remainder of the lowercase letters are symbols and logos from the game. The ducky is even there... hehe

I will be modifying this font and adding more detail as I have more time. If you see any glaring errors, or have comments/criticisms let me know at the address above.

Now the legal mumbo jumbo... (I couldn't fit it all in the descriptor for the font)

� Crytek Studios. All Rights Reserved. Published by UbiSoft Entertainment.
Far Cry, UbiSoft, ubi.com, and the UbiSoft logo are trademarks of UbiSoft Entertainment in the U.S. and/or other countries.

NVIDIA logo is Trademark of NVIDIA Corp.

All other images/logos are property of their respective owners.

Uh, I think that covers it.. :)



-Mike "Gumby" Anderson
